import numpy as np

e_f = 1e-15 # machine precission

def ndiff(fun, x, full=False):
    # initial guess for dx
    dx = 1e-5
    # define derivative
    def deriv(fun, x, dx):
        return (fun(x + dx) - fun(x - dx))/(2*dx)
    # using the centered third order derivative for error
    def third_deriv(fun, x, dx):
        return (fun(x + 2*dx) - 2*fun(x + dx) + 2*fun(x - dx) - fun(x - 2*dx))/(2*dx**3)
    # iterating once
    dx_opt = np.power(e_f*abs(fun(x)/third_deriv(fun, x, dx)), 1/3)
    if dx_opt == 0 or dx_opt == np.inf:
        dx_opt = 1e-5
    error = e_f*abs(fun(x)/dx_opt) + abs(third_deriv(fun, x, dx_opt))*dx_opt**2
    if full:
        return (deriv(fun, x, dx_opt), dx_opt, error)
    else:
        return deriv(fun, x, dx_opt)
    
